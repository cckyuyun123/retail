# import pandas as pd
# data1 = pd.read_excel('C:/Users/0-0/Desktop/实践项目/cumcm2018c1.xlsx')
# data2 = pd.read_csv('C:/Users/0-0/Desktop/实践项目/cumcm2018c2.csv')
# data = pd.merge(data1, data2, how='outer', on='kh')
# data3 = data.dropna(subset=['kh'])
#
# data3['dtime'] = pd.to_datetime(data3['dtime'])
# df = data3[['kh','dtime','je']]
# assert isinstance(df.dropna, object)
# df = df.dropna(subset=['kh', 'dtime', 'je'])
# r = df.groupby('kh')['dtime'].max().reset_index()
# print(r.head())
# r['R'] = (pd.to_datetime('2018-2-1')-r['dtime']).dt.days
# r = r[['kh', 'R']]
# print(r.head())
# df['日期标签'] = df['dtime'].astype(str).str[:10]
# dup_f = df.groupby(['kh', '日期标签'])['dtime'].count().reset_index()
# f = dup_f.groupby('kh')['dtime'].count().reset_index()
# f.columns=['kh', 'F']
# print(f.head())
# sum_m=df.groupby('kh')['je'].sum().reset_index()
# sum_m.columns = ['kh', '总消费金额']
# com_m = pd.merge(sum_m, f, left_on='kh', right_on='kh', how='inner')
# com_m['M'] = com_m['总消费金额']/com_m['F']
# print(com_m.head())
#
# rfm = pd.merge(r, com_m, left_on='kh', right_on='kh', how='inner')
# rfm = rfm[['kh', 'R', 'F', 'M']]
# print(rfm.head())
#
# #RFM分值计算
# rfm['R-SCORE'] = pd.cut(rfm['R'],bins=[0,30,60,90,120,10000],labels=[5,4,3,2,1],right=False).astype(float)
# rfm['F-SCORE'] = pd.cut(rfm['F'],bins=[1,2,3,4,5,10000],labels=[1,2,3,4,5],right=False).astype(float)
# rfm['M-SCORE'] = pd.cut(rfm['M'],bins=[0,50,100,150,200,10000],labels=[1,2,3,4,5],right=False).astype(float)
#
# rfm['R是否大于均值'] = (rfm['R-SCORE']>rfm['R-SCORE'].mean())*1
# rfm['F是否大于均值'] = (rfm['F-SCORE']>rfm['F-SCORE'].mean())*1
# rfm['M是否大于均值'] = (rfm['M-SCORE']>rfm['M-SCORE'].mean())*1
# print(rfm.head())
#
# #RFM模型客户分层
# rfm['人群数值'] = (rfm['R是否大于均值']*100)+(rfm['F是否大于均值']*10)+(rfm['M是否大于均值']*1)
# print(rfm.head())
#
# def transform_label(x):
#     if x == 111:
#         label = '重要价值客户'
#     elif x == 110:
#         label = '消费潜力客户'
#     elif x == 101:
#         label = '频次深耕客户'
#     elif x == 100:
#         label = '新客户'
#     elif x == 11:
#         label = '重要价值流失预警客户'
#     elif x == 10:
#         label = '一般价值客户'
#     elif x == 1:
#         label = '高消费唤回客户'
#     elif x == 0:
#         label = '流失客户'
#     return label
# rfm['人群类型'] = rfm['人群数值'].apply(transform_label)
# print(rfm.head())
#
# data = pd.merge(data,rfm, how='outer', on='kh')
# dw = data.dropna(subset=['kh','csrq','xb','djsj','dtime','人群类型'])
# print(dw)
#
# dw['month'] = dw['dtime'].dt.month
# dw['hour'] = dw['dtime'].dt.hour
# dw = dw[['kh','csrq','xb','djsj','month','hour','je','spmc','jf','人群类型']]
# print(dw)


import matplotlib.pyplot as plt
import wordcloud
dic = {'cc3f5c56':'14', '33岁':'15', '女性':'15','5年会龄':'13','化妆品':'14','重要价值客户':'14'}
wc = wordcloud.WordCloud(scale=16,font_path='simhei.ttf',background_color='white',max_words=50,colormap="coolwarm")
X = wc.generate_from_frequancies(dic)
plt.axis('off')
plt.imshow(X)