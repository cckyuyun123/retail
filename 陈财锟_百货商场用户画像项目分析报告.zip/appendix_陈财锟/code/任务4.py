import pandas as pd
data1 = pd.read_excel('C:/Users/0-0/Desktop/实践项目/cumcm2018c1.xlsx')
data2 = pd.read_csv('C:/Users/0-0/Desktop/实践项目/cumcm2018c2.csv')
data = pd.merge(data1, data2, how='outer', on='kh')
data3 = data.dropna(subset=['kh'])



# print(data3)
# print(data3.dtypes)

data3['dtime'] = pd.to_datetime(data3['dtime'])
df = data3[['kh','dtime','je']]
assert isinstance(df.dropna, object)
df = df.dropna(subset=['kh', 'dtime', 'je'])
r = df.groupby('kh')['dtime'].max().reset_index()
print(r.head())
r['R'] = (pd.to_datetime('2018-2-1')-r['dtime']).dt.days
r = r[['kh', 'R']]
print(r.head())

df['日期标签'] = df['dtime'].astype(str).str[:10]
dup_f = df.groupby(['kh', '日期标签'])['dtime'].count().reset_index()
f = dup_f.groupby('kh')['dtime'].count().reset_index()
f.columns=['kh', 'F']
print(f.head())

sum_m=df.groupby('kh')['je'].sum().reset_index()
sum_m.columns = ['kh', '总消费金额']
com_m = pd.merge(sum_m, f, left_on='kh', right_on='kh', how='inner')
com_m['M'] = com_m['总消费金额']/com_m['F']
print(com_m.head())

rfm = pd.merge(r, com_m, left_on='kh', right_on='kh', how='inner')
rfm = rfm[['kh', 'R', 'F', 'M']]
print(rfm.head())

#RFM分值计算
rfm['R-SCORE'] = pd.cut(rfm['R'],bins=[0,30,60,90,120,10000],labels=[5,4,3,2,1],right=False).astype(float)
rfm['F-SCORE'] = pd.cut(rfm['F'],bins=[1,2,3,4,5,10000],labels=[1,2,3,4,5],right=False).astype(float)
rfm['M-SCORE'] = pd.cut(rfm['M'],bins=[0,50,100,150,200,10000],labels=[1,2,3,4,5],right=False).astype(float)

rfm['R是否大于均值'] = (rfm['R-SCORE']>rfm['R-SCORE'].mean())*1
rfm['F是否大于均值'] = (rfm['F-SCORE']>rfm['F-SCORE'].mean())*1
rfm['M是否大于均值'] = (rfm['M-SCORE']>rfm['M-SCORE'].mean())*1
print(rfm.head())

#RFM模型客户分层
rfm['人群数值'] = (rfm['R是否大于均值']*100)+(rfm['F是否大于均值']*10)+(rfm['M是否大于均值']*1)
print(rfm.head())

def transform_label(x):
    if x == 111:
        label = '重要价值客户'
    elif x == 110:
        label = '消费潜力客户'
    elif x == 101:
        label = '频次深耕客户'
    elif x == 100:
        label = '新客户'
    elif x == 11:
        label = '重要价值流失预警客户'
    elif x == 10:
        label = '一般价值客户'
    elif x == 1:
        label = '高消费唤回客户'
    elif x == 0:
        label = '流失客户'
    return label
rfm['人群类型'] = rfm['人群数值'].apply(transform_label)
print(rfm.head())

count = rfm['人群类型'].value_counts().reset_index()
count.columns = ['客户类型', '人数']
count['人数占比']=count['人数']/count['人数'].sum()
print(count)

rfm['消费总金额'] = rfm['F']*rfm['M']
mon = rfm.groupby('人群类型')['消费总金额'].sum().reset_index()
mon.columns = ['客户类型','消费金额']
mon['金额占比'] = mon['消费金额']/mon['消费金额'].sum()
print(mon)

import seaborn as sns
import matplotlib
import matplotlib.pyplot as plt

# 设置字体、图形样式
sns.set_style("whitegrid")
matplotlib.rcParams['font.sans-serif'] = ['SimHei']
matplotlib.rcParams['font.family'] = 'sans-serif'
matplotlib.rcParams['axes.unicode_minus'] = False

# matplotlib.fontsize='15'
# 取做图数据
x = range(len(count['客户类型']))
y1 = count['人数']
y2 = count['人数占比']

# 设置图形大小
plt.rcParams['figure.figsize'] = (12.0, 5.0)
fig = plt.figure()

# 柱状图
ax1 = fig.add_subplot(111)
ax1.bar(x, y1, alpha=.2, color='g')
ax1.set_ylabel('人数（人）', fontsize='15')
ax1.set_title("各类型客户人数分布及占比", fontsize='20')
plt.yticks(fontsize=15)
plt.xticks(x, count['客户类型'])
plt.xticks(fontsize=15)

# 折线图
ax2 = ax1.twinx()
ax2.plot(x, y2, 'r', marker='*', ms=10)
ax2.set_xlim([-0.5, 7.5])
ax2.set_ylim([0, 0.55])
ax2.set_ylabel('人数占比', fontsize='15')
ax2.set_xlabel('人数占比')

# 纵轴标签
plt.yticks(fontsize=15)
plt.xticks(x, count['客户类型'])
plt.xticks(fontsize=15)
plt.grid(False)

# 添加数据标签
# for x, y, z in zip(x, y2, y1):
#     plt.text(x, y + 0.3, str(y), ha='center', va='bottom', fontsize=20, rotation=0)
#     plt.text(x, z - z, str(int(z)), ha='center', va='bottom', fontsize=21, rotation=0)
# plt.show()




x = range(len(mon['客户类型']))
y1 = mon['消费金额']
y2 = mon['金额占比']

# 设置图形大小
plt.rcParams['figure.figsize'] = (12.0, 5.0)
fig = plt.figure()

# 柱状图
ax1 = fig.add_subplot(111)
ax1.bar(x, y1, alpha=.2, color='g')
ax1.set_ylabel('金额（元）', fontsize='15')
ax1.set_title("各类型客户消费金额分布及占比", fontsize='20')
plt.yticks(fontsize=15)
plt.xticks(x, mon['客户类型'])
plt.xticks(fontsize=15)

# 折线图
ax2 = ax1.twinx()
ax2.plot(x, y2, 'r', marker='*', ms=10)
ax2.set_xlim([-0.5, 7.5])
ax2.set_ylim([0, 0.55])
ax2.set_ylabel('金额占比', fontsize='15')
ax2.set_xlabel('金额占比')

# 纵轴标签
plt.yticks(fontsize=15)
plt.xticks(x, mon['客户类型'])
plt.xticks(fontsize=15)
plt.grid(False)

# 添加数据标签
# for x, y, z in zip(x, y2, y1):
#     plt.text(x, y + 0.3, str(y), ha='center', va='bottom', fontsize=20, rotation=0)
#     plt.text(x, z - z, str(int(z)), ha='center', va='bottom', fontsize=21, rotation=0)
# plt.show()



data = pd.merge(data, rfm, how='outer', on='kh')
print(data.head(30))
print(data.dtypes)

# data['age'] = 2020-data['csrq'].dt.year
# data['入会时长'] = 2020-data['djsj'].dt.year
# data['dtime'] = pd.to_datetime(data['dtime'])
# data['消费月份'] = data['dtime'].dt.month
# data['消费时间'] = data['dtime'].dt.hour
# data['折扣'] = data['je']/(data['sl']*data['sj'])
#
#
# dk1_0 = data[['age', 'xb', '入会时长', '消费月份', '消费时间', '折扣', 'sj', 'je', '人群数值']]
# #print(dk1_0)
# dk =dk1_0.dropna(subset=['age', 'xb', '入会时长', '消费月份', '消费时间', '折扣', 'sj', 'je', '人群数值'])
# print(dk)
#
# from sklearn.preprocessing import StandardScaler
# from sklearn.cluster import KMeans
# import numpy as np
# sc = StandardScaler()
# dkM = sc.fit_transform(dk)
# print(dkM)
# model = KMeans(n_clusters=5, random_state=0, max_iter=500)
# fit_model = model.fit(dkM)
# print('聚类中心\n',model.cluster_centers_)
# print('类别\n',pd.Series(model.labels_).value_counts)
# angles = np.linspace(0,2*np.pi, 9, endpoint=False)
# angles = np.concatenate((angles,[angles[0]]))
# centers = model.cluster_centers_
# plot_data = np.concatenate((centers,centers[:,[0]]),axis=1)
# print(angles)
# label=['age', 'xb', '入会时长', '消费月份', '消费时间', '折扣', 'sj', 'je', '人群数值']
# import matplotlib.pyplot as plt
# fig = plt.figure(figsize=(6,6))
# ax=fig.add_subplot(111,polar=True)
# for i in range(len(plot_data)):
#     ax.plot(angles,plot_data[i],'o-',label='聚类群体')
# ax.set_thetagrids(angles*180/np.pi,label)
# plt.legend(bbox_to_anchor=(0.8,1.15),ncol=3)
# plt.show()