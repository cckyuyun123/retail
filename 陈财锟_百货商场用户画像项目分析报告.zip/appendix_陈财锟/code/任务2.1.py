import pandas as pd
import pandas as pd
data1 = pd.read_excel('C:/Users/0-0/Desktop/实践项目/cumcm2018c1.xlsx')
data2 = pd.read_csv('C:/Users/0-0/Desktop/实践项目/cumcm2018c2.csv')
data = pd.merge(data1, data2, how='outer', on='kh')
print(data)
data3 = data.dropna(subset=['kh','dtime'])
print(data3)
data1['nl'] = 2020 - data1['csrq'].dt.year
bins = [1,15,30,60,121]
labels = ['少年', '青年', '中年', '老年']
data1['年龄段'] = pd.cut(data1['nl'],bins,right=False,labels=labels)
data_gb1_0 = data1[['年龄段','xb']].groupby(by='年龄段')
print(data_gb1_0.count())

data3['nl'] = 2020 - data3['csrq'].dt.year
data3['年龄段'] = pd.cut(data3['nl'],bins,right=False,labels=labels)
data_gb1_1 = data3[['年龄段','je']].groupby(by='年龄段')
data1_1 = data_gb1_1.count()
print(data1_1)
import matplotlib.pyplot as plt
plt.figure(figsize=(10,6))
elements_1= ['少年', '青年', '中年', '老年']
weight_1 = [393,8614, 140637, 9877]
wedges, texts, autotexts = plt.pie(weight_1,autopct="%3.1f%%",)
plt.legend(wedges, elements_1)
print(plt.show())

import numpy as np
print(data_gb1_1.agg(np.sum))
import matplotlib.pyplot as plt
plt.figure(figsize=(10,6))
elements_1= ['少年', '青年', '中年', '老年']
weight_1 = [1.295446e+06, 1.748464e+07, 6.073915e+08, 2.925846e+07]
wedges, texts, autotexts = plt.pie(weight_1,autopct="%3.1f%%",)
plt.legend(wedges,elements_1)
print(plt.show())

data_gb1_2 = data3[['xb','je']].groupby(by='xb')
data1_2 = data_gb1_2.count()
print(data1_2)
import numpy as np
data_gb1_2.agg(np.sum)
import matplotlib.pyplot as plt
plt.figure(figsize=(10,6))
elements_1= ['男', '女']
weight_1 = [5.933822e+08, 7.988931e+07]
wedges, texts, autotexts = plt.pie(weight_1,autopct="%3.1f%%",)
plt.legend(wedges,elements_1)
print(plt.show())

data_gb1_3 = data1[['xb','kh']].groupby(by='xb')
data1_3 = data_gb1_3.count()

import matplotlib.pyplot as plt
plt.figure(figsize=(10,6))
elements_1= ['男', '女']
weight_1 = [35685, 149640]
wedges, texts, autotexts = plt.pie(weight_1,autopct="%3.1f%%",)
plt.legend(wedges,elements_1)
print(plt.show())










































