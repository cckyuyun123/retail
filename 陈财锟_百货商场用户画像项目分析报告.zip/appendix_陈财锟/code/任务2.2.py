import pandas as pd
data1 = pd.read_excel('C:/Users/0-0/Desktop/百货商场用户画像/cumcm2018c1.xlsx')
data2 = pd.read_csv('C:/Users/0-0/Desktop/百货商场用户画像/cumcm2018c2.csv')
data = pd.merge(data1, data2, how='outer', on='kh')
data3 = data.dropna(subset=['kh'])

import matplotlib.pyplot as plt
plt.figure(figsize=(8,6))
elements= [" 会员", "非会员"]
weight = [459077, 243005]
wedges, texts, autotexts = plt.pie(weight,autopct="%3.1f%%",)
plt.legend(wedges,elements)
print(plt.show())

import numpy as np
data['je'].sum()
data4 = data.dropna(subset=['kh'])
a = data4['je'].sum()
b = data['je'].sum()-data4['je'].sum()
import matplotlib.pyplot as plt
plt.figure(figsize=(10, 6))
elements= [" 会员", "非会员"]
weight = [a, b]
wedges, texts, autotexts = plt.pie(weight,autopct="%3.1f%%",)
plt.legend(wedges,elements)
print(plt.show())

data3['year'] = data3['dtime'].dt.year
data3_gb1_2 = data3[['year', 'je']].groupby(by='year')
data3_gb1_2.count()
import numpy as np
data3_gb1_2.agg(np.sum)
import matplotlib.pyplot as plt
plt.figure(figsize=(6,4))
name_list = ['2015','2016','2017','2018']
num_list = [3.001116e+08,3.444590e+08,5.207898e+08,7.235350e+06]
plt.bar(range(len(num_list)), num_list,color='rgb',tick_label=name_list)
print(plt.show())

data4 = data.dropna(subset=['dtime'])
data4
data3['dtime']
data3['dtime'] = pd.to_datetime(data3['dtime'])
data3['YearMonth'] = data3['dtime'].map(lambda x: 1000*x.year + x.month)
data3['YearMonth']
data3_gb1_1 = data3[['YearMonth', 'je']].groupby(by = 'YearMonth')
data3_gb1_1.count()
import numpy as np
data3_1 = data3_gb1_1.agg(np.sum)
data3_1
import matplotlib.pyplot as plt
plt.figure(figsize=(14,8))
x_data = data3_1['YearMonth']
y_data = data3_1['je']
plt.plot(x_data,y_data,)
print(plt.show())

x_data = ['2015001','2015002','2015003','2015004','2015005','2015006','2015007','2015008','2015012','2016001','2016003','2016004','2016005','2016006',
'2016007','2016008','2016009','2016010','2016011','2016012','2017001','2017002','2017003','2017004','2017005','2017006','2017007','2017008','2017009',
'2017010','2017011','2017012','2018001']
y_data = [3.898855e+07,5.002932e+07,4.562215e+07,3.084289e+07,4.223079e+07,3.254355e+07,2.863788e+07,3.101327e+07,2.032260e+05,
         4.629701e+06,2.216560e+07,2.728971e+07,3.630051e+07,2.771333e+07,2.871680e+07,3.482761e+07,3.918950e+07,3.003899e+07,5.796944e+07,3.561778e+07,
         5.116009e+07,3.030558e+07,4.518570e+07,3.505910e+07,3.873761e+07,3.347596e+07,3.631790e+07,4.618452e+07,5.351354e+07,
         3.753520e+07,6.628646e+07,4.702813e+07,7.235350e+06]
plt.plot(x_data,y_data,)
print(plt.show())



















