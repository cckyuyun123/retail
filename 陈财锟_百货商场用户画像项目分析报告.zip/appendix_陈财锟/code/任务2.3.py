import pandas as pd
data1 = pd.read_excel('C:/Users/0-0/Desktop/百货商场用户画像/cumcm2018c1.xlsx')
data2 = pd.read_csv('C:/Users/0-0/Desktop/百货商场用户画像/cumcm2018c2.csv')
data = pd.merge(data1, data2, how='outer', on='kh')
data3 = data.dropna(subset=['kh'])

import matplotlib.pyplot as plt
data3['hour'] = data3['dtime'].dt.hour
bins = [0,7,12,14,19,25]
labels = ['凌晨', '上午','中午', '下午', '晚上']
data3['时间段'] = pd.cut(data3['hour'],bins,right=False,labels=labels)
data3_gb1_4 = data3[['时间段', 'kh']].groupby(by = '时间段')
data3_gb1_4.count()
import matplotlib.pyplot as plt
plt.figure(figsize=(10,6))
elements_1= ['凌晨', '上午', '中午', '下午', '晚上']
weight_1 = [189, 87455, 145170, 444773, 198560]
wedges, texts, autotexts = plt.pie(weight_1,autopct="%3.1f%%",)
plt.legend(wedges,elements_1)
print(plt.show())

data3['month'] = data3['dtime'].dt.month
data3['month']
bins = [0,3,6,9,12,13]
labels = ['冬季1', '春季', '夏季', '秋季', '冬季2']
data3['季节'] = pd.cut(data3['month'],bins,right=False,labels=labels)
data3_gb1_3 = data3[['季节', 'kh']].groupby(by = '季节')
data3_gb1_3.count()
import matplotlib.pyplot as plt
plt.figure(figsize=(10,8))
elements_1= ['春季', '夏季', '秋季', '冬季']
weight_1 = [265895, 236955, 186336, 186960]
wedges, texts, autotexts = plt.pie(weight_1,autopct="%3.1f%%",)
plt.legend(wedges,elements_1)
print(plt.show())










